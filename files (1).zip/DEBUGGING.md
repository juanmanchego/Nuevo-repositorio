# Informe de depuración · UserManagementAPI v2

Tras desplegar la versión inicial, TechHive Solutions reportó tres tipos de fallo: usuarios añadidos sin validación adecuada, errores al recuperar usuarios inexistentes y bloqueos por excepciones no controladas. Este documento recoge los errores encontrados, su causa, la corrección aplicada y cómo se verificó.

## 1. Errores identificados

Cada error se reprodujo contra la versión 1 antes de corregirlo.

### Validación de entrada

| # | Síntoma (v1) | Causa |
|---|---|---|
| V1 | Se aceptaba el correo `a@b` (201) | `[EmailAddress]` solo exige que haya una `@` |
| V2 | Se aceptaban nombres como `123$$` y apellidos como `<script>` (201) | Nombres y apellidos solo tenían límite de longitud, sin restricción de caracteres |
| V3 | `jobTitle: null` devolvía 400 "The JobTitle field is required." en inglés, aunque el campo es opcional | Con los tipos de referencia no anulables activados, .NET marca todo `string` como obligatorio de forma implícita |
| V4 | Un cuerpo vacío devolvía dos errores, uno de ellos en inglés | Misma causa que V3, sumada a los mensajes por defecto del enlace de modelos |
| V5 | Un correo con espacios alrededor (`" ana@x.com "`) se rechazaba en vez de recortarse | La validación se ejecuta antes del `Trim()` del servicio |

### Búsquedas y gestión de errores

| # | Síntoma (v1) | Causa |
|---|---|---|
| E1 | `GET /api/users/-5` devolvía 404 "no existe", cuando el ID en sí no es válido | No se validaba el rango del ID |
| E2 | `GET /api/users/99999999999` devolvía un 404 **sin cuerpo** | La restricción de ruta `{id:int}` no encontraba coincidencia y respondía antes del controlador |
| E3 | Las rutas inexistentes devolvían 404 sin cuerpo | No había `UseStatusCodePages` ni `AddProblemDetails` |
| E4 | Una excepción no controlada mostraba la página de error de desarrollo con la traza de pila, o una respuesta genérica en producción, sin registrar el error con un identificador | Solo existía `UseExceptionHandler` en producción; no había middleware global ni logging del error |

### Rendimiento y concurrencia

| # | Síntoma (v1) | Causa |
|---|---|---|
| R1 | Con 20.000 usuarios, `GET /api/users` devolvía **3,9 MB** en una sola respuesta | Sin paginación: se devolvía la colección completa |
| R2 | Comprobar si un correo existía recorría todos los usuarios (O(n)) | No había índice por correo |
| R3 | "Comprobar correo + insertar" no era atómico; dos peticiones simultáneas podían crear correos duplicados | La comprobación y la inserción eran dos pasos separados sin bloqueo. **No se llegó a reproducir** en 300 peticiones concurrentes, pero el riesgo existía por diseño |
| R4 | Las respuestas JSON viajaban sin comprimir | No estaba activada la compresión de respuestas |

## 2. Correcciones aplicadas

**Validación (V1-V5)**
- Nueva clase base `UserRequestBase` con las reglas compartidas por POST y PUT, en lugar de duplicarlas.
- Expresiones regulares en `Validation/ValidationPatterns.cs`: nombres solo con letras (con tildes y ñ), espacios, guiones o apóstrofos; correo con dominio y extensión; departamento sin símbolos extraños; cargo sin `<` ni `>`.
- `JobTitle` pasa a ser `string?` y se desactivó el requerido implícito (`SuppressImplicitRequiredAttributeForNonNullableReferenceTypes`). Lo obligatorio se declara solo con `[Required]`.
- Mensajes del enlace de modelos traducidos al español en `Program.cs`.
- Las expresiones toleran espacios al inicio y al final; el servicio recorta los valores y guarda el correo en minúsculas.

**Búsquedas y excepciones (E1-E4)**
- Los parámetros `id` usan `[Range(1, int.MaxValue)]`, y la ruta pasó de `{id:int}` a `{id}`. Ahora IDs negativos, no numéricos o fuera de rango devuelven 400 con un mensaje claro, y un ID válido que no existe devuelve 404 con `ProblemDetails` y se registra en el log.
- `AddProblemDetails()` y `UseStatusCodePages()` garantizan cuerpo `ProblemDetails` en cualquier respuesta de error.
- Nuevo `Middleware/ExceptionHandlingMiddleware.cs`, primero en el pipeline. Envuelve toda la petición en un `try-catch`, registra el error con método, ruta y `traceId`, y devuelve un 500 `ProblemDetails` sin traza de pila. Distingue las cancelaciones del cliente, que no son errores del servidor.
- Nueva excepción `DuplicateEmailException`. El servicio la lanza y el controlador la captura con `try-catch` para responder 409.
- `ArgumentNullException.ThrowIfNull` en el servicio como defensa ante entradas nulas.

**Rendimiento y concurrencia (R1-R4)**
- `GET /api/users` ahora es paginado (`page`, `pageSize` de 1 a 100, 20 por defecto) y admite `department` y `search`. Devuelve `items`, `page`, `pageSize`, `totalCount` y `totalPages`.
- Índice `ConcurrentDictionary<string, int>` por correo (sin distinguir mayúsculas): la comprobación de duplicados pasa de O(n) a O(1).
- Las escrituras (crear, actualizar, eliminar) usan un `lock`, así que comprobar e insertar es atómico. Las lecturas siguen sin bloquearse.
- Compresión Brotli y Gzip con `AddResponseCompression`.

## 3. Resultados de las pruebas

**Colección de Postman** (`postman/`): 35 peticiones y 66 aserciones, todas correctas. Se ejecutó dos veces seguidas con el mismo resultado, porque la colección limpia los datos que crea.

**Antes y después:**

| Caso | v1 | v2 |
|---|---|---|
| Correo `a@b` | 201 ❌ | 400 ✅ |
| Nombre `123$$` / `<script>` | 201 ❌ | 400 ✅ |
| `jobTitle: null` | 400 en inglés ❌ | 201 ✅ |
| Correo con espacios y mayúsculas | 400 ❌ | 201, guardado normalizado ✅ |
| Correo duplicado con otras mayúsculas | 409 | 409 ✅ |
| Cuerpo vacío | 400 con mensaje duplicado en inglés | 400 con un solo mensaje en español ✅ |
| `GET /users/-5` | 404 ❌ | 400 ✅ |
| `GET /users/abc` y `/99999999999` | 404 sin cuerpo ❌ | 400 con detalle ✅ |
| `GET /users/999` | 404 | 404 `ProblemDetails` + log ✅ |
| Ruta inexistente | 404 sin cuerpo ❌ | 404 `ProblemDetails` ✅ |
| Excepción no controlada | Traza de pila / sin registro ❌ | 500 `ProblemDetails` con `traceId`, registrado en el log ✅ |
| 300 POST simultáneos con el mismo correo | 1 creado (riesgo latente) | 1 creado, 299 × 409, garantizado por el `lock` ✅ |

**Rendimiento con 20.005 usuarios:**

| Petición | v1 | v2 |
|---|---|---|
| `GET /api/users` | 3.876.966 bytes | 3.931 bytes (20 elementos) |
| `GET /api/users?pageSize=100` | — | 19.041 bytes |
| `GET /api/users?pageSize=100` con gzip | — | 1.625 bytes |

## 4. Cómo ayudó Microsoft Copilot

> ⚠️ **Completa esta sección con tu experiencia real.** Abajo tienes los prompts sugeridos para cada paso. Ejecútalos en Copilot sobre el código de la v1, compara lo que te propone con las correcciones de este informe y anota lo que aceptaste, lo que ajustaste y lo que descartaste.

**Identificar errores**
- *"Analiza CreateUserRequest y dime qué entradas inválidas se aceptarían todavía."* → Esperable: detectar que `[EmailAddress]` acepta `a@b` y que los nombres admiten números y HTML (V1, V2).
- *"/explain ¿Por qué `jobTitle: null` devuelve 'field is required' si no tiene [Required]?"* → Esperable: explicar el requerido implícito de los tipos no anulables (V3).
- *"¿Qué pasa en esta API si se lanza una excepción dentro de un controlador en producción?"* → Esperable: señalar la falta de un manejador global y de logging (E4).
- *"Revisa GET /api/users: ¿qué problemas de rendimiento tendría con 20.000 usuarios?"* → Esperable: sugerir paginación y un índice por correo (R1, R2).
- *"¿Este servicio Singleton es seguro si llegan dos POST con el mismo correo a la vez?"* → Esperable: detectar la condición de carrera (R3).

**Corregir errores**
- *"Crea un middleware que capture excepciones no controladas, las registre y devuelva ProblemDetails sin la traza de pila."*
- *"Añade paginación a GET /api/users con page y pageSize validados, máximo 100."*
- *"Haz atómica la comprobación de correo duplicado en InMemoryUserService."*

**Probar**
- *"Genera casos de prueba en Postman para entradas inválidas, IDs negativos, no numéricos e inexistentes."*

**Lo que tuve que corregir de las sugerencias:** *(anota aquí cualquier propuesta de Copilot que fuera incorrecta o incompleta; por ejemplo, validar el correo sin tolerar espacios, o paginar sin límite máximo de tamaño).*
