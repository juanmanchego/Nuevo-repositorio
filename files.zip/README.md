# UserManagementAPI

API REST de gestión de usuarios para las herramientas internas de **TechHive Solutions**. Permite a los departamentos de RR.HH. y TI crear, consultar, actualizar y eliminar registros de usuarios.

## Stack

- .NET 8 · ASP.NET Core Web API (controladores)
- Almacenamiento en memoria (`ConcurrentDictionary`) detrás de la interfaz `IUserService`
- Validación con Data Annotations y `[ApiController]`
- Errores en formato `ProblemDetails`
- Swagger / OpenAPI (Swashbuckle) para documentación y pruebas

## Estructura

```
UserManagementAPI/
├── Controllers/UsersController.cs      Endpoints CRUD
├── DTOs/CreateUserRequest.cs           Datos de entrada para POST
├── DTOs/UpdateUserRequest.cs           Datos de entrada para PUT
├── Models/User.cs                      Entidad de usuario
├── Services/IUserService.cs            Contrato del servicio
├── Services/InMemoryUserService.cs     Implementación en memoria
├── Program.cs                          Servicios y pipeline de middleware
├── UserManagementAPI.http              Pruebas desde Visual Studio
└── postman/                            Colección de Postman
```

## Cómo ejecutarla

```bash
dotnet restore
dotnet run --launch-profile http
```

- API: `http://localhost:5000/api/users`
- Swagger UI: `http://localhost:5000/swagger`

En Visual Studio basta con abrir el proyecto y pulsar F5. La API arranca con tres usuarios de ejemplo. Los datos se pierden al reiniciar, porque se guardan en memoria.

## Endpoints

| Método | Ruta | Descripción | Respuestas |
|---|---|---|---|
| GET | `/api/users` | Lista todos los usuarios. Filtro opcional `?department=TI` | 200 |
| GET | `/api/users/{id}` | Obtiene un usuario por ID | 200, 404 |
| POST | `/api/users` | Crea un usuario | 201, 400, 409 |
| PUT | `/api/users/{id}` | Actualiza un usuario existente | 200, 400, 404, 409 |
| DELETE | `/api/users/{id}` | Elimina un usuario | 204, 404 |

Ejemplo de cuerpo para POST:

```json
{
  "firstName": "Carlos",
  "lastName": "Mendoza",
  "email": "carlos.mendoza@techhive.com",
  "department": "TI",
  "jobTitle": "Soporte técnico"
}
```

Para PUT se envían los mismos campos más `isActive` (reemplazo completo del registro).

**Reglas de validación:** nombre y apellido obligatorios (2 a 50 caracteres), correo obligatorio con formato válido y único (sin distinguir mayúsculas), departamento obligatorio. Los errores de validación devuelven 400 con el detalle por campo; un correo repetido devuelve 409.

## Pruebas

**Postman:** importa `postman/UserManagementAPI.postman_collection.json` y ejecútala en orden con el *Collection Runner*. Incluye 11 peticiones con 15 aserciones que cubren casos correctos y de error (404, 400, 409). La variable `userId` se guarda automáticamente al crear el usuario y se reutiliza en PUT y DELETE.

**Visual Studio:** abre `UserManagementAPI.http` y pulsa "Send Request" sobre cada petición.

Resultados verificados:

| Prueba | Esperado | Resultado |
|---|---|---|
| GET lista | 200 con arreglo | ✅ |
| GET por departamento | 200 solo usuarios de TI | ✅ |
| GET /1 | 200 | ✅ |
| GET /999 | 404 | ✅ |
| POST válido | 201 + cabecera Location | ✅ |
| POST inválido | 400 con errores por campo | ✅ |
| POST correo duplicado | 409 | ✅ |
| PUT válido | 200 con `updatedAt` | ✅ |
| PUT /999 | 404 | ✅ |
| DELETE | 204 | ✅ |
| DELETE repetido | 404 | ✅ |

## Cómo ayudó Microsoft Copilot

> ⚠️ **Completa esta sección con tu experiencia real.** Abajo tienes los prompts sugeridos para cada paso y el tipo de mejora que Copilot suele aportar. Sustituye los ejemplos por lo que Copilot te sugirió de verdad y por los cambios que aceptaste o corregiste.

**1. Configuración del proyecto (Program.cs)**
- Prompt: *"Configura Program.cs para una API web ASP.NET Core con controladores, Swagger solo en desarrollo, HTTPS y manejo de errores en producción."*
- Aporte: generó el código repetitivo de servicios y el orden del pipeline de middleware.

**2. Modelo y DTOs**
- Prompt: *"Crea una clase User con Id, nombre, apellido, correo, departamento, cargo, estado y fechas, y DTOs de creación y actualización con validaciones."*
- Aporte: propuso separar entidad y DTOs, y añadir `[Required]`, `[EmailAddress]` y `[StringLength]`.

**3. Endpoints CRUD**
- Prompt: *"Genera un UsersController con GET (todos y por id), POST, PUT y DELETE usando IUserService."*
- Aporte: generó los cinco endpoints con los códigos HTTP correctos (`CreatedAtAction`, `NoContent`, `NotFound`).

**4. Mejoras sugeridas al revisar el código**
- Prompt: *"/explain ¿Qué problemas tiene este servicio si recibe peticiones concurrentes?"*
- Aporte: recomendó `ConcurrentDictionary` e `Interlocked.Increment` para el servicio Singleton.
- Prompt: *"¿Qué casos límite no estoy controlando en POST y PUT?"*
- Aporte: detectó que se podían registrar correos duplicados; se añadió la respuesta 409.

**5. Pruebas**
- Prompt: *"Genera una colección de Postman con pruebas para todos los endpoints, incluidos los casos de error."*
- Aporte: generó las peticiones y los scripts de aserciones.

**Lo que tuve que corregir de las sugerencias:** *(anota aquí cualquier sugerencia de Copilot que fuera incorrecta o que ajustaste, por ejemplo mensajes de validación en inglés, rutas o códigos de estado).*

## Siguientes pasos

- Sustituir el almacenamiento en memoria por Entity Framework Core con SQL Server (solo cambia el registro en `Program.cs`).
- Añadir autenticación JWT y autorización por roles (RR.HH. / TI).
- Pruebas unitarias con xUnit y Moq sobre `UsersController`.
