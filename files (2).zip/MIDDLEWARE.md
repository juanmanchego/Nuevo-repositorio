# Middleware · UserManagementAPI v3

Para cumplir las políticas corporativas de TechHive Solutions, la API incorpora tres middlewares propios: **gestión de errores estandarizada**, **autenticación por token** y **registro de auditoría**. Este documento explica cada uno, el orden del pipeline, cómo se probaron y cómo se usó Copilot.

## 1. Pipeline

```
Petición
  │
  ▼
┌─────────────────────────────────┐
│ 1. ExceptionHandlingMiddleware  │  try-catch de todo lo que sigue → JSON 500
├─────────────────────────────────┤
│    UseStatusCodePages           │  404/405 sin cuerpo → JSON estándar
│    HSTS · HTTPS · Compresión    │
│    Swagger (solo Development)   │  público, antes de la autenticación
├─────────────────────────────────┤
│ 2. TokenAuthenticationMiddleware│  sin token válido → 401 y corta la cadena
├─────────────────────────────────┤
│ 3. RequestLoggingMiddleware     │  audita petición y respuesta
├─────────────────────────────────┤
│    Controladores                │
└─────────────────────────────────┘
```

```csharp
app.UseErrorHandling();        // 1. Gestión de errores
app.UseStatusCodePages(...);
app.UseHttpsRedirection();
app.UseResponseCompression();
app.UseSwagger(); ...          // (solo Development)
app.UseTokenAuthentication();  // 2. Autenticación
app.UseRequestLogging();       // 3. Registro
app.MapControllers();
```

**Por qué este orden**

- **Errores primero**, porque un middleware solo puede capturar las excepciones de lo que se ejecuta *después* de él. Así cubre la autenticación, el registro y los controladores.
- **Autenticación antes que el registro y los controladores**, para rechazar lo antes posible las peticiones sin token. Una petición no autorizada no consume tiempo en registro, enrutamiento, validación ni lógica de negocio. Es el punto de cortocircuito más barato del pipeline.
- **Registro al final**, justo antes de los controladores. Así cada entrada de auditoría incluye el **cliente autenticado** (`rrhh-portal`, `ti-console`), que solo se conoce después de validar el token.
- **Swagger antes de la autenticación**, para que la documentación sea accesible en desarrollo sin token.

**Consecuencia del orden y cómo se resuelve:** como el registro va después de la autenticación, las peticiones rechazadas con 401 nunca llegan al middleware de registro. Para no perder esos intentos en la auditoría, el propio middleware de autenticación los registra con nivel `Warning`, indicando método, ruta, motivo y `traceId`. Así **todas** las peticiones quedan registradas.

## 2. Middleware de gestión de errores

`Middleware/ExceptionHandlingMiddleware.cs`

- Envuelve todo el resto del pipeline en un `try-catch`.
- Excepción no controlada → registra el error completo (con traza) en el log y responde **500** con `{ "error": "Error interno del servidor.", ... }`. El cliente nunca ve la traza de pila.
- `BadHttpRequestException` (errores de protocolo del cliente) → responde con su propio código 4xx.
- Cancelación por parte del cliente → se registra como información, no como error.
- Si la respuesta ya había empezado a enviarse, no intenta reescribirla (evita una segunda excepción).

**Formato de error único en toda la API.** No basta con capturar las excepciones: los 400, 401, 404, 405 y 409 también usan el mismo formato.

```json
{ "error": "No existe un usuario con ID 999.", "status": 404, "traceId": "0HNOUF...:00000001" }
```

Los errores de validación añaden `details` con los mensajes por campo:

```json
{
  "error": "Uno o más campos no son válidos.",
  "status": 400,
  "traceId": "0HNOUF...:00000001",
  "details": { "Email": ["El correo no tiene un formato válido (ejemplo: nombre@empresa.com)."] }
}
```

| Origen | Código | Cómo se genera |
|---|---|---|
| Excepción no controlada | 500 | `ExceptionHandlingMiddleware` |
| Token ausente o inválido | 401 | `TokenAuthenticationMiddleware` |
| Validación de modelos | 400 | `InvalidModelStateResponseFactory` en `Program.cs` |
| Usuario inexistente / correo duplicado | 404 / 409 | `ApiControllerBase.Error()` |
| Ruta inexistente / método no permitido | 404 / 405 | `UseStatusCodePages` en `Program.cs` |

Todos los textos están en `Middleware/ErrorMessages.cs`, y todas las respuestas se construyen con `ErrorResponseWriter`. El `traceId` coincide con el del log, así que soporte puede localizar el error exacto.

## 3. Middleware de autenticación

`Middleware/TokenAuthenticationMiddleware.cs` · `Auth/JwtTokenService.cs` · `Controllers/AuthController.cs`

**Flujo**

1. La aplicación cliente (portal de RR.HH. o consola de TI) pide un token en `POST /api/auth/token` con su `clientId` y `clientSecret`. Es la única ruta pública junto con `/swagger`.
2. La API devuelve un **JWT firmado con HMAC-SHA256**, válido 60 minutos.
3. En cada petición, el cliente envía `Authorization: Bearer {token}`.
4. El middleware valida el token. Si es correcto, asigna `HttpContext.User` y continúa. Si no, responde **401** con el formato estándar y la cabecera `WWW-Authenticate: Bearer`, y **no llama a `next()`**.

**Qué se valida**

| Comprobación | Si falla |
|---|---|
| Cabecera presente con esquema `Bearer` | 401 "Se requiere un token de acceso." / "no es válido." |
| Tres partes, Base64Url y JSON correctos | 401 (nunca 500 con un token corrupto) |
| Algoritmo exactamente `HS256` (rechaza `alg: none`) | 401 |
| Firma, comparada en tiempo constante | 401 |
| Emisor (`iss`) y audiencia (`aud`) | 401 |
| Vigencia (`exp`, `nbf`) con 30 s de margen de reloj | 401 "El token de acceso ha expirado." |

**Decisiones de diseño**

- Se implementó con `System.Security.Cryptography`, sin paquetes externos. El token es un JWT estándar que puede inspeccionarse en jwt.io. En un proyecto real con acceso a NuGet se podría sustituir por `Microsoft.AspNetCore.Authentication.JwtBearer` cambiando solo `ITokenService` y el registro.
- Los secretos de cliente también se comparan en tiempo constante, para no revelar información por temporización.
- La configuración se valida **al arrancar** (`ValidateOnStart`): si falta la clave de firma o tiene menos de 32 bytes, la aplicación no inicia, en lugar de fallar en la primera petición.
- La clave y los clientes de `appsettings.Development.json` son **solo para desarrollo**. En `appsettings.json` la clave está vacía a propósito; en producción se configura con variables de entorno (`Auth__SigningKey`, `Auth__Clients__0__ClientSecret`...) o un gestor de secretos como Azure Key Vault.

**Error encontrado durante las pruebas.** La primera versión comparaba los **bytes decodificados** de la firma. Al alterar el último carácter del token, la API seguía respondiendo 200: ese carácter lleva 2 bits de relleno que el decodificador Base64 ignora, así que algunas variantes decodificaban a la misma firma. No permitía falsificar tokens, pero sí aceptar tokens alterados. Se corrigió comparando la **cadena Base64Url canónica**. Tras el cambio se probaron 18 variantes del último carácter y un payload modificado (`"sub": "admin"`): todas devuelven 401.

## 4. Middleware de registro

`Middleware/RequestLoggingMiddleware.cs`

Registra dos entradas por petición, enlazadas por el `traceId`:

```
2026-09-29 23:12:07.510 info: UserManagementAPI.Audit[1000] → POST /api/users | cliente: ti-console | traceId: 0HNOUFS899FS7:00000001
2026-09-29 23:12:07.557 info: UserManagementAPI.Audit[1001] ← POST /api/users respondió 201 en 46.6 ms | cliente: ti-console | traceId: 0HNOUFS899FS7:00000001
```

- **Datos:** método HTTP, ruta, código de estado, duración, cliente autenticado y `traceId`.
- **Nivel según el resultado:** `Information` para 2xx y 3xx, `Warning` para 4xx y `Error` para 5xx. Así se pueden filtrar los fallos fácilmente.
- **Excepciones:** si la petición lanza una excepción, la entrada de respuesta se registra igualmente como 500 antes de que la excepción suba al middleware de errores.
- **Privacidad:** no registra cabeceras (el token viaja en `Authorization`), cadenas de consulta ni cuerpos.
- **Categoría propia** `UserManagementAPI.Audit`, para poder enviar la auditoría a un destino separado (archivo, Seq, Application Insights) desde la configuración.
- **Rendimiento:** usa `[LoggerMessage]`, que genera el código de registro en compilación y evita el análisis de plantillas y la asignación de memoria en cada petición. Se mide el tiempo con `Stopwatch.GetTimestamp()`, sin crear objetos.

Ejemplo real de las pruebas, con los distintos casos:

```
warn: TokenAuthenticationMiddleware  Acceso denegado (401) a GET /api/users: sin token (TraceId ...FS5)
info: Audit[1000] → GET /api/users | cliente: ti-console | traceId: ...FS6
info: Audit[1001] ← GET /api/users respondió 200 en 10.5 ms | cliente: ti-console | traceId: ...FS6
warn: Audit[1001] ← POST /api/users respondió 400 en 7.0 ms | cliente: ti-console | traceId: ...FS8
warn: Audit[1001] ← GET /api/users/999 respondió 404 en 3.3 ms | cliente: ti-console | traceId: ...FS9
fail: Audit[1001] ← GET /api/diagnostics/throw respondió 500 en 0.4 ms | cliente: ti-console | traceId: ...FSB
fail: ExceptionHandlingMiddleware  Error no controlado en GET /api/diagnostics/throw (TraceId ...FSB) System.InvalidOperationException: ...
```

## 5. Rendimiento del pipeline

- Las peticiones no autorizadas se rechazan antes del registro, el enrutamiento y los controladores.
- Registro con `[LoggerMessage]` y sin leer cuerpos de petición ni respuesta (leerlos obligaría a almacenarlos en memoria).
- Compresión Brotli y Gzip para las respuestas JSON.
- Servicios de token y de usuarios como Singleton: la clave de firma se convierte a bytes una sola vez al arrancar.

## 6. Pruebas

**Colección de Postman** (`postman/`): 35 peticiones y **90 aserciones**, todas correctas en dos ejecuciones seguidas. La autenticación se configura a nivel de colección (`Bearer {{token}}`), y un script común comprueba que **toda** respuesta de error cumple el formato `{ error, status, traceId }`.

| Grupo | Casos |
|---|---|
| Autenticación | Token correcto; credenciales incorrectas, cliente inexistente y credenciales vacías; sin token; esquema Basic; token mal formado; firma alterada; token expirado; `alg: none`; firmado con otra clave; audiencia incorrecta; token válido |
| CRUD | Listar, filtrar, paginar, obtener, crear, actualizar y eliminar con token, incluidos 400, 404 y 409 |
| Gestión de errores | Excepción no controlada (500 sin traza); la misma ruta sin token (401, demuestra que la autenticación va antes); ruta inexistente (404); método no permitido (405) |

Los tokens expirados, con `alg: none`, con otra clave y con otra audiencia están firmados con la clave de desarrollo y fijados en la colección, así que las pruebas son reproducibles. Si cambias la clave de desarrollo, esas pruebas seguirán dando 401, pero por firma inválida y no por el motivo original.

**Validación de los registros.** Tras las dos ejecuciones, el log contenía 104 entradas de auditoría (una de entrada y otra de salida por cada petición autenticada) y 18 rechazos 401 registrados por el middleware de autenticación, cada uno con su motivo: `Expired`, `InvalidSignature`, `InvalidAudience`, `UnsupportedAlgorithm`, `Malformed`, "sin token" y "esquema distinto de Bearer".

## 7. Cómo ayudó Microsoft Copilot

> ⚠️ **Completa esta sección con tu experiencia real.** Abajo tienes los prompts sugeridos para cada paso. Ejecútalos en Copilot, compara lo que te propone con esta implementación y anota lo que aceptaste, lo que ajustaste y lo que descartaste.

**Paso 2: registro**
- *"Genera middleware para registrar solicitudes y respuestas HTTP en ASP.NET Core con método, ruta, código de estado y duración."*
- Revisa si la propuesta registra la respuesta cuando hay una excepción, y si evita registrar el token o los cuerpos.

**Paso 3: gestión de errores**
- *"Crea un middleware que capture excepciones no controladas y devuelva { \"error\": \"Internal server error.\" } en JSON."*
- *"¿Cómo hago que los errores de validación 400 y los 404 usen el mismo formato JSON?"*

**Paso 4: autenticación**
- *"Escribe un middleware que valide un token Bearer y devuelva 401 si no es válido."*
- *"¿Qué ataques debo contemplar al validar un JWT a mano?"* → Esperable: `alg: none`, comparación en tiempo constante, validación de `exp`, `iss` y `aud`.

**Paso 5: orden**
- *"¿En qué orden deben ir los middlewares de errores, autenticación y registro en Program.cs, y por qué?"*
- *"Si el registro va después de la autenticación, ¿qué peticiones no se registran?"*

**Paso 6: pruebas**
- *"Genera pruebas de Postman para tokens válidos, inválidos, expirados y alterados."*

**Lo que tuve que corregir de las sugerencias:** *(por ejemplo: si la propuesta de Copilot comparaba la firma con `==` en lugar de en tiempo constante, no validaba el algoritmo, o dejaba los 401 sin registrar por el orden del pipeline).*
